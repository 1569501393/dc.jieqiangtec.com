<?php
/**
 * 惩罚大转盘
 *
 * 作者:微赞
 *
 * qq : 15595755
 */
defined('IN_IA') or exit('Access Denied');

class weisrc_clubbigwheelModule extends WeModule
{
}