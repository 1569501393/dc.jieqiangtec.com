<?php
/**
 * 财务中心模块定义
 *
 * @author Kim 模块开发QQ:800083075
 * @url http://www.012wz.com/
 */
defined('IN_IA') or exit('Access Denied');

class Kim_financialModule extends WeModule {


}