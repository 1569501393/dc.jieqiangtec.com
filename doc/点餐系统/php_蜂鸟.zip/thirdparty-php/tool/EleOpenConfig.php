<?php
	// 联调环境地址 const API_URL = 'https://exam-anubis.ele.me/anubis-webapi';
	// 线上环境地址 const API_URL = 'https://open-anubis.ele.me/anubis-webapi';
const API_URL = 'https://exam-anubis.ele.me/anubis-webapi';
const APP_ID = '1dce54a7-1997-4589-b5f1-639a38793d05';    //填入正确的app_id
const SECRET_KEY = '934cbff6-6214-48c3-9d00-42fd46cceb79';    // 填入正确的secret_key
