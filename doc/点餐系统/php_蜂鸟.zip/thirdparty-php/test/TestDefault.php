<?php
function test($a = "jj") {
  echo $a;
}

test();
